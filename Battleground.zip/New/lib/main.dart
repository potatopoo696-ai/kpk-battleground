import 'package:flame/game.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: KPKMenu(),
  ));
}

class KPKMenu extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF0B3D0B),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("KPK BATTLEGROUND", style: TextStyle(fontSize: 26, color: Colors.white, fontWeight: FontWeight.bold)),
            SizedBox(height: 10),
            Text("100% FREE - 10 Player Battle", style: TextStyle(color: Colors.white70)),
            SizedBox(height: 5),
            Text("Map: Peshawar | Mardan | Swat", style: TextStyle(color: Colors.white54, fontSize: 12)),
            SizedBox(height: 30),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (_) => GameScreen()));
              },
              child: Text("PLAY FREE - MARDAN DROP"),
            ),
          ],
        ),
      ),
    );
  }
}

class GameScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GameWidget(game: KPKGame()),
    );
  }
}

class KPKGame extends FlameGame {
  @override
  Future<void> onLoad() async {
    print("KPK FREE Game Loaded");
  }
}